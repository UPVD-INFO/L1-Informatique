/*
 * Copyright (c) 2018 Helmut Neemann.
 * Use of this source code is governed by the GPL v3 license
 * that can be found in the LICENSE file.
 */

/**
 * The handlers which control the external processes
 */
package de.neemann.digital.core.extern.handler;
