/*
 * Copyright (c) 2016 Helmut Neemann
 * Use of this source code is governed by the GPL v3 license
 * that can be found in the LICENSE file.
 */

/**
 * Classes to format a whole truth table
 */
package de.neemann.digital.analyse.format;
